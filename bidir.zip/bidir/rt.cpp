// rt: un lanzador de rayos minimalista
// g++ -O3 -fopenmp rt.cpp -o rt

#include <math.h>
#include <stdlib.h>
#include <stdio.h>  
#include <omp.h>
#include <vector>
#include <random>
#include <algorithm> // std::min_element
#include <iterator>  // std::begin, std::end
#include <iostream>
#include <unistd.h>
#include <map>

#include "sphere.h"
#include "sampling_helpers.h"
#include "bsdf.h"
#include "light_path.h"

using namespace std;

Sphere spheres[] = {
	//Escena: radio, posicion, color, emision, material
	Sphere(1e5,  Point(-1e5 - 49, 0, 0),   Color(.75, .25, .25), Color(),         diffuse), // pared izq
	Sphere(1e5,  Point(1e5 + 49, 0, 0),    Color(.25, .25, .75), Color(),	      diffuse), // pared der
	Sphere(1e5,  Point(0, 0, -1e5 - 81.6), Color(.25, .75, .25), Color(),	      diffuse), // pared detras
	Sphere(1e5,  Point(0, -1e5 - 40.8, 0), Color(.25, .75, .75), Color(),	      diffuse), // suelo
	Sphere(1e5,  Point(0, 1e5 + 40.8, 0),  Color(.75, .75, .25), Color(),	      diffuse), // techo
	Sphere(16.5, Point(-23, -24.3, -34.6), Color(1, 1, 1),	     Color(),	      specular), // esfera espejo
	Sphere(16.5, Point(23, -24.3, -3.6),   Color(1, 1, 1),       Color(), 		  dielectric), // esfera dielectrica
	Sphere(10.5, Point(0, 24.3, 0),        Color(0, 0, 0),       Color(10,10,10), diffuse)  // esfera de luz
};
// Sphere spheres[] = {
// 	//Escena: radio, posicion, color, emision, material
// 	Sphere(1e5,  Point(-1e5 - 49, 0, 0),   Color(.75, .25, .25), Color(),         diffuse), // pared izq
// 	Sphere(1e5,  Point(1e5 + 49, 0, 0),    Color(.25, .25, .75), Color(),	      diffuse), // pared der
// 	Sphere(1e5,  Point(0, 0, -1e5 - 81.6), Color(.25, .75, .25), Color(),	      diffuse), // pared detras
// 	Sphere(1e5,  Point(0, -1e5 - 40.8, 0), Color(.25, .75, .75), Color(),	      diffuse), // suelo
// 	Sphere(1e5,  Point(0, 1e5 + 40.8, 0),  Color(.75, .75, .25), Color(),	      diffuse), // techo
// 	Sphere(16.5, Point(-23, -24.3, -34.6), Color(1, 1, 1),	     Color(),	      specular), // esfera espejo
// 	Sphere(16.5, Point(23, -24.3, -3.6),   Color(1, 1, 1), 	     Color(),	      specular), // esfera dielectrica
// 	Sphere(1.5, Point(-40, -39.3, -60),        Color(0, 0, 0),       Color(600,600,600), diffuse)  // esfera de luz
// };

double totalShperes = sizeof(spheres)/sizeof(Sphere);

// calcular la intersección del rayo r con todas las esferas
// regresar true si hubo una intersección, falso de otro modo
// almacenar en t la distancia sobre el rayo en que sucede la interseccion
// almacenar en id el indice de spheres[] de la esfera cuya interseccion es mas cercana
inline bool intersect(const Ray &r, double &t, int &id) {
	double dist;
	double thresh = t = 100000000000;

	for (int i=0;i < totalShperes;i++) {
		dist = spheres[i].intersect(r);
		if (dist && dist > 0.01 && dist < t) {
			t = dist;
			id = i;
		}
	}
	if (t < thresh) return true;
	else return false;
}

std::map<int, Sphere> lights;
unsigned int totalLights;

void getLights(){
	for (int i = 0; i < totalShperes; i++) {
		Sphere obj = spheres[i];
		if (obj.e.x <= 0 && obj.e.y <= 0 && obj.e.z <= 0)
			continue;
		else {
			lights.insert(std::make_pair(i, obj));
		}
	}
	totalLights = lights.size();
}

std::vector<LightPath> makeLightPath(const int bounces) {
	std::vector<LightPath> lightPath;
	lightPath.reserve(bounces*totalLights);
	std::map<int,Sphere>::const_iterator it;

	for(it = lights.begin(); it != lights.end(); it++) {
		
		Sphere light = it->second;
		Vector lightPosition = light.p;

		Vector dir = sphereAreaDir();
		dir.normalize();
		
		Ray r = Ray(lightPosition + dir * light.r, dir);
		double t;
		int id = 0;
		
		Vector gatheredColor(0,0,0);
		Vector gatheredRefl(1,1,1);
		
		for(int i = 0; i < bounces; i++) {
			if(!intersect(r, t, id)) {
				continue;
			}
			const Sphere &obj = spheres[id];	

			Vector x = r.o + r.d*t;	

			Vector n = (x - obj.p).normalize();
			Vector nv;
			if (n.dot(r.d * -1) > 0) {nv = n;}
			else {nv = n * -1;}

			Color baseColor = obj.c;
			gatheredRefl = gatheredRefl.mult(baseColor);
			gatheredColor = gatheredRefl.mult(light.e);

			
			Vector dir;
			if (obj.mat == diffuse) {
				lightPath.push_back(LightPath(x, gatheredColor, it->first, id));
				dir = DirectionBSDF::DiffuseBSDF(n);
			}
			else if (obj.mat == specular) {
				dir = DirectionBSDF::SpecularBSDF(r, n);
			}
			else if(obj.mat == dielectric) {
				double n2, ni = 1.0, nt = 1.5;
				Vector wi = r.d * -1;

				double cosTi = (wi).dot(n);
				cosTi = Clamp(cosTi, -1, 1);
				bool out2in = cosTi > 0.f;
				if(!out2in){
					swap(ni, nt);
					cosTi = fabs(cosTi);
				}
				n2 = ni/nt;

				double cosTt = snell(cosTi, n2);

				double F = dielectricFresnel(ni, nt, n2, cosTi, cosTt);

				bool reflect = dis(gen) < F;

				dir = DirectionBSDF::DielectricBSDF(r, wi, nv, n2, cosTi, cosTt, reflect);
			}
			else {
				dir = Vector();
			}

			r = Ray(x, dir);
		}
	}

	return lightPath;
}

// funcion para determinar BRDF
Color BRDF(Color c) {
	Color brdf = c * invPi;
	return brdf;
}

// check if a light point and an object point see each other
// no intersection between other things in the scene
// lightPoint: light point (used for ray origin)
// objDirection: direction to the object point which is checked
// id: the id of the object
bool checkOcclusion(const Point &lightPoint, const Vector &objDirection, int id) {

	Ray r(lightPoint, objDirection);
	int id1 = 0;
	double t;
	if(intersect(r, t, id1)) {
		return (id1 == id);
	}
	return false;
}

/* Shoot shadow ray from object intersection from camera path (if object material is diffuse) to each intersection of the light path
 * lightPath: The path which was calculated by the makeLightPath() function
 * obj: the object that was hit by a camera ray
 * x: intersection point where the object was hit
 * id: id of the hit object
 * returns Color influence to Ray
 * */
Color shadowRay(const std::vector<LightPath> &lightPath, const Sphere &obj, const Point &x, Vector &n, int id) {
	Vector G;

	if(obj.mat == diffuse) {
		for(int i = 0; i < lightPath.size(); i++) {
			//create directional vector between camera hitpoint and light path hitpoint
			Vector dir = lightPath[i].x - x ;
			Vector dirNorm = dir.normalize();
			//is there a shadowray?
			// std::cout << "Conection?: " << checkOcclusion(lightPath[i].x, dir_norm*-1., id) << std::endl;
			if(checkOcclusion(lightPath[i].x, dirNorm*-1., id)) {
				// normal of light path hit point
				Vector lightPathNorm = (lightPath[i].x - spheres[lightPath[i].obj].p).normalize();

				//the diffuse PDF for the enlightend object
				double diff_enlight_pdf = fabs((dirNorm * -1.).dot(lightPathNorm)) * invPi;
				//the diffuse PDF for the camera object
				double diff_eye_pdf = fabs(dirNorm.dot(n)) * invPi;

				double distance_sqr = x.squaredDistance(lightPath[i].x);
				// std::cout << "Sqr dist: " << distance_sqr << std::endl;
				//First light constant which has to be added
				G = G + lightPath[i].color * diff_enlight_pdf * (diff_eye_pdf / distance_sqr);
				//e = e + (light_paths[i].absorbed_color * (dir.Dot(object.GetNormal(hit_point) * diffPdf))) / M_PI;

			}
			else {
				//Ignore if they don't see eachother
				continue;	
			}

		}
	}
	return G;
}

Color directLightValue(Vector &x, Vector &n, Color &bsdf,double &continueprob){
	Color directLight;
	std::map<int,Sphere>::const_iterator it;
	for(it = lights.begin(); it != lights.end(); it++) {
		const Sphere &temp = ((it)->second);
		if (temp.e.x <= 0 && temp.e.y <= 0 && temp.e.z <= 0)
			continue;
		
		double theta1, phi1, cosTmax, probLight;
		paramSolidAngle(x, theta1, phi1, cosTmax, temp);
		Vector wc = (temp.p - x).normalize();
		Vector wl = sampleDir(wc, theta1, phi1).normalize();
		double t;
		int id = 0;
		if (intersect(Ray(x, wl), t, id) && id == it->first){	// si no hay oclusion, calcular iluminacion directa
			Color Le = temp.e;
			double dotCos1 = n.dot(wl);
			probLight = probSolidAngle(cosTmax);
			directLight = directLight + Le.mult(bsdf * fabs(dotCos1) * (1.0 / (probLight*continueprob)));
		}
	}
	return directLight;
}



// Calcula el valor de color para el rayo dado
Color shade(const Ray &ray, const std::vector<LightPath> &lightPath) {
	double t;
	int id = 0;
	int bounce = 0;
	int maxBounce = 10;
	bool checkLightPath = true;
	Ray r = ray;
	Vector gatheredColor(0,0,0);
	Vector gatheredRefl(1,1,1);

	for(int i = 0;; i++) {

		// determinar que esfera (id) y a que distancia (t) el rayo intersecta
		if (!intersect(r, t, id))
			return Color();	// el rayo no intersecto objeto, return Vector() == negro
	
		const Sphere &obj = spheres[id];  //esfera sobre la que se intersecto

		if (++bounce > maxBounce) return gatheredColor;

		// std::cout << "Bounces " << bounce << std::endl;

		// determinar coordenadas del punto de interseccion
		Point x = r.o + r.d*t;

		// determinar la dirección normal en el punto de interseccion
		Vector n = (x - obj.p).normalize();

		// determinar si un rayo choca con un objeto por dentro
		// si es el caso,  voltear  la normal (nv)
		Vector nv;
		if (n.dot(r.d * -1) > 0) {nv = n;}
		else {nv = n * -1;}

		// color del objeto intersectado
		Color baseColor = obj.c;
		
		if(checkLightPath || obj.mat != diffuse)
			gatheredColor = gatheredColor + gatheredRefl.mult(obj.e);

		// ruleta rusa
		double q = 0.1;
		double continueprob = 1.0 - q;
		if (dis(gen) < q) return gatheredColor;

		gatheredRefl = gatheredRefl.mult(baseColor);

		// determinar el color que se regresara
		
		Vector newDir;

		// material difuso

		if (obj.mat == diffuse) {
			Vector newDir = DirectionBSDF::DiffuseBSDF(n);
			Color bsdf = BRDF(baseColor);
			bool notLight = lights.find(id) == lights.end();

			if(!notLight && i == 0){
				gatheredColor = gatheredColor + gatheredRefl.mult(obj.e);
			}
			else if(notLight || checkLightPath){
				gatheredColor = gatheredColor + gatheredRefl.mult(directLightValue(x, n, bsdf, continueprob));
			}
			checkLightPath = false;
			Vector G = shadowRay(lightPath, obj, x, n, id);
			// std::cout << "Geometric x value: " << G.x << std::endl;
			gatheredColor = gatheredColor + gatheredRefl.mult(G);

			// double probMat = probCosineHemisphere(wi, n);
			// double dotCos = n.dot(wi);
			// Ray newRay = Ray(x, wi);

			// Color indirectLight = bsdf.mult(shade(newRay, bounce, 0)) * (fabs(dotCos)/(probMat*continueprob));
			// Color directLight = directLightValue(x, n, bsdf, continueprob);
			// return obj.e * cond + directLight + indirectLight;
		}
		
		// material especular 

		else if (obj.mat == specular){
			newDir = DirectionBSDF::SpecularBSDF(r, n);  // direccion de refleccion especular ideal
			checkLightPath = true;
			// wr.normalize();
			// return baseColor.mult(shade(Ray(x, wr), bounce, 1));
		}

		// material dielectrico

		else if (obj.mat == dielectric) {
			double n2, ni = 1.0, nt = 1.5;
			Vector wi = r.d * -1;

			double cosTi = (wi).dot(n);
			cosTi = Clamp(cosTi, -1, 1);
			bool out2in = cosTi > 0.f;
			if(!out2in){
				swap(ni, nt);
				cosTi = fabs(cosTi);
			}
			n2 = ni/nt;

			double cosTt = snell(cosTi, n2);

			double F = dielectricFresnel(ni, nt, n2, cosTi, cosTt);

			bool reflect = dis(gen) < F;

			Vector newDir = DirectionBSDF::DielectricBSDF(r, wi, nv, n2, cosTi, cosTt, reflect);

			checkLightPath = true;

			// double prob = probDielectric(F, reflect);

			// Ray newRay = Ray(x, wo);

			// if (reflect){
			// 	double f = F / fabs(cosTi);
			// 	return obj.e + baseColor.mult(shade(newRay, bounce, 1)) * (f*fabs(nv.dot(wo))/prob);
			// }
			// else {
			// 	double f = (((nt*nt)/(ni*ni))*(1 - F)) / fabs(cosTt);
			// 	return obj.e + baseColor.mult(shade(newRay, bounce, 1))*(f*fabs(nv.dot(wo))/prob);
			}
		else{
			newDir = Vector();
			checkLightPath = true;
		}

		r = Ray(x, newDir);
	}
	
}

int main(int argc, char *argv[]) {

	getLights();
	std::cout << "Total lights: " << totalLights << std::endl;
	
	int w = 1024, h = 768; // image resolution

	int N = 32;  // numero de muestras

	// fija la posicion de la camara y la dirección en que mira
	Ray camera( Point(0, 11.2, 214), Vector(0, -0.042612, -1).normalize() );

	// parametros de la camara
	Vector cx = Vector( w * 0.5095 / h, 0., 0.); 
	Vector cy = (cx % camera.d).normalize() * 0.5095;
  
	// auxiliar para valor de pixel y matriz para almacenar la imagen
	Color *pixelColors = new Color[w * h];

	// PROYECTO 1
	// usar openmp para paralelizar el ciclo: cada hilo computara un renglon (ciclo interior),
	// omp_set_num_threads(h);
	#pragma omp parallel
	#pragma omp for schedule(dynamic, 1)

	for(int y = 0; y < h; y++) 
	{ 
		// recorre todos los pixeles de la imagen
		fprintf(stderr,"\r%5.2f%%",100.*y/(h-1));

		for(int x = 0; x < w; x++ ) {
			for (int n=0; n<N; n++){

				std::vector<LightPath> lightPath = makeLightPath(5);
				// if (x == 0 && y == 0 && n < 10) {
				// 	std::cout << "Light Paths for the First Pixel:" << std::endl;
				// 	std::cout << "Light Path size: " << lightPath.size() << std::endl;
				// 	std::cout << "Iteration " << n << ": " << std::endl;
				// 	std::cout << "Position (x): " << lightPath[0].x << std::endl;
				// 	std::cout << "Color: " << lightPath[0].color << std::endl;
				// 	std::cout << "Associated Light: " << lightPath[0].light << std::endl;
				// 	std::cout << "Associated Object: " << lightPath[0].obj << std::endl;
            	// }
				int idx = (h - y - 1) * w + x; // index en 1D para una imagen 2D x,y son invertidos
				Color pixelValue = Color(); // pixelValue en negro por ahora
				// para el pixel actual, computar la dirección que un rayo debe tener
				Vector cameraRayDir = cx * ( double(x)/w - .5) + cy * ( double(y)/h - .5) + camera.d;

				// computar el color del pixel para el punto que intersectó el rayo desde la camara
				pixelValue = pixelValue + shade( Ray(camera.o, cameraRayDir.normalize()), lightPath) * (1.0/N);

				// limitar los tres valores de color del pixel a [0,1]
				pixelColors[idx] = pixelColors[idx] + Color(clamp(pixelValue.x), clamp(pixelValue.y), clamp(pixelValue.z));
			}
		}
	}

	fprintf(stderr,"\n");

	FILE *f = fopen("image.ppm", "w");
	// escribe cabecera del archivo ppm, ancho, alto y valor maximo de color
	fprintf(f, "P3\n%d %d\n%d\n", w, h, 255); 
	for (int p = 0; p < w * h; p++) 
	{ // escribe todos los valores de los pixeles
    		fprintf(f,"%d %d %d ", toDisplayValue(pixelColors[p].x), toDisplayValue(pixelColors[p].y), 
				toDisplayValue(pixelColors[p].z));
  	}
  	fclose(f);

  	delete[] pixelColors;

	return 0;
}